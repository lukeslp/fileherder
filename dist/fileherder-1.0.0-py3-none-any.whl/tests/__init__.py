"""Tests for fileherder package."""
